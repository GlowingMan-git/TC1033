#pragma once

class motor_general
{
protected:
    int horsepower;

public:
    void setHorsepower(int hp);
    int getHorsepower();
};